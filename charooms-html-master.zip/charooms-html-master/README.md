
该套模板是在N年以前在学校写的，代表了当年的自己最高水准了[捂脸]，支持响应式，使用了 `bootstrap` 框架。

[预览](https://zfowed.github.io/charooms-html/login.html)

## 1、登录页

![登录页](https://github.com/zfowed/charooms-html/raw/master/screenshots/login.jpg)

## 2、首页

![首页](https://github.com/zfowed/charooms-html/raw/master/screenshots/index.jpg)

## 3、聊天室页

![聊天室页](https://github.com/zfowed/charooms-html/raw/master/screenshots/room.jpg)
